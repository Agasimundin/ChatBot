const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');

function sendMessage() {
    const message = userInput.value.trim();
    if (message) {
        displayMessage(message, 'user-message');
        userInput.value = '';
        getBotResponse(message);
    }
}

function displayMessage(message, className) {
    const messageElement = document.createElement('div');
    messageElement.className = `message ${className}`;
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

async function getBotResponse(userMessage) {
    try {
        const response = await fetch('YOUR_CHATBOT_API_ENDPOINT', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: userMessage }),
        });
        const data = await response.json();
        displayMessage(data.response, 'bot-message');
    } catch (error) {
        displayMessage('Sorry, there was an error. Please try again.', 'bot-message');
    }
}
document.addEventListener("DOMContentLoaded", function() {
    document.querySelector(".speech-bubble").classList.add("show");
  });
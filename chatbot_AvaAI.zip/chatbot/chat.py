import os
from openai import OpenAI


client = OpenAI(api_key="sk-proj-EohuyBe1IPw7bZ5vFkPVT3BlbkFJVuoS3EK43Z9saeAQ7HXB")
def chat_with_me(user_input):
    chat_completion = client.chat.completions.create(
        messages=[
            {"role": "user", "content": user_input}
        ],
        model="gpt-3.5-turbo"
    )
    return chat_completion.choices[0].message.content

user_input = "Hello"
response = chat_with_me(user_input)
print(response)